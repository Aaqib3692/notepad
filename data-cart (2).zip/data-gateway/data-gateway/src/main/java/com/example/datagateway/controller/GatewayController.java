package com.example.datagateway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class GatewayController {
	@Autowired
   private RestTemplate template;
   
   @GetMapping("/{id}")
   public String Hi(@PathVariable int id) {
	  return "Hi "+id+" I am in gateway";
	   
   }
   @GetMapping("/welcome/{id}")
   public String welcome(@PathVariable int id) {
	   String url="http://User-Service/user/"+id;
	   return template.getForObject(url, String.class); 
   }
   
   @GetMapping("/products/{name}")
	public String products(@PathVariable String name) {
		String url = "http://User-Service/user/products/" +name;
		return template.getForObject(url, String.class);
	}
   
}
