package com.example.datagateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
