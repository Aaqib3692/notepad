package com.example.datauser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private RestTemplate template;

	@GetMapping("/{id}")
	public String welcome(@PathVariable int id) {

		String url = "http://Cart-Service/cart/" + id;
		return template.getForObject(url, String.class);
	}

	@GetMapping("/id/{id}")
	public String Hi(@PathVariable int id) {
		return "Hi " + id + " I am in User";
	}

	@GetMapping("/products/{name}")
	public String products(@PathVariable String name) {
		
		
		String url = "http://Cart-Service/cart/products/" + name;
		return template.getForObject(url, String.class);
	}

}
