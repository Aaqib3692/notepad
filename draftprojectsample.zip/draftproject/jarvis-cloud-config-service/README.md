# notes for placing config in cloud
## locations where spring config looks for config

### server config(application.properties)
```
    server.port=8888
    spring.cloud.config.server.native.searchLocations=file:///C:/workspace/config/, file:///C:/workspace/config/
    spring.profiles.active=native
```


### client config(bootstrap.properties)
```
    spring.cloud.config.name=snap
    spring.cloud.config.uri=http://localhost:8888
    spring.cloud.config.profile=db,git
```

#### sample log output
```
    'file:/C:/workspace/config/snap.properties' (file:///C:/workspace/config/snap.properties)
    'file:/C:/workspace/config/snap.xml' (file:///C:/workspace/config/snap.xml)
    'file:/C:/workspace/config/snap.yml' (file:///C:/workspace/config/snap.yml)
    'file:/C:/workspace/config/snap.yaml' (file:///C:/workspace/config/snap.yaml)
    'file:/C:/workspace/config/application.properties' (file:///C:/workspace/config/application.properties)
    'file:/C:/workspace/config/application.xml' (file:///C:/workspace/config/application.xml)
    'file:/C:/workspace/config/application.yml' (file:///C:/workspace/config/application.yml)
    'file:/C:/workspace/config/application.yaml' (file:///C:/workspace/config/application.yaml)
    'file:/C:/workspace/config/snap.properties' (file:///C:/workspace/config/snap.properties) for profile db
    'file:/C:/workspace/config/snap-db.properties' (file:///C:/workspace/config/snap.properties) for profile db
    'file:/C:/workspace/config/snap-db.xml' (file:///C:/workspace/config/snap-db.xml) for profile db
    'file:/C:/workspace/config/snap-db.xml' (file:///C:/workspace/config/snap-db.xml) for profile db
    'file:/C:/workspace/config/snap.xml' (file:///C:/workspace/config/snap.xml) for profile db
    'file:/C:/workspace/config/snap-db.yml' (file:///C:/workspace/config/snap-db.yml) for profile db
    'file:/C:/workspace/config/snap-db.yml' (file:///C:/workspace/config/snap-db.yml) for profile db
    'file:/C:/workspace/config/snap.yml' (file:///C:/workspace/config/snap.yml) for profile db
    'file:/C:/workspace/config/snap-db.yaml' (file:///C:/workspace/config/snap-db.yaml) for profile db
    'file:/C:/workspace/config/snap-db.yaml' (file:///C:/workspace/config/snap-db.yaml) for profile db
    'file:/C:/workspace/config/snap.yaml' (file:///C:/workspace/config/snap.yaml) for profile db
    'file:/C:/workspace/config/application-db.properties' (file:///C:/workspace/config/application-db.properties) for profile db
    'file:/C:/workspace/config/application-db.properties' (file:///C:/workspace/config/application-db.properties) for profile db
    'file:/C:/workspace/config/application.properties' (file:///C:/workspace/config/application.properties) for profile db
    'file:/C:/workspace/config/application-db.xml' (file:///C:/workspace/config/application-db.xml) for profile db
    'file:/C:/workspace/config/application-db.xml' (file:///C:/workspace/config/application-db.xml) for profile db
    'file:/C:/workspace/config/application.xml' (file:///C:/workspace/config/application.xml) for profile db
    'file:/C:/workspace/config/application-db.yml' (file:///C:/workspace/config/application-db.yml) for profile db
    'file:/C:/workspace/config/application-db.yml' (file:///C:/workspace/config/application-db.yml) for profile db
    'file:/C:/workspace/config/application.yml' (file:///C:/workspace/config/application.yml) for profile db
    'file:/C:/workspace/config/application-db.yaml' (file:///C:/workspace/config/application-db.yaml) for profile db
    'file:/C:/workspace/config/application-db.yaml' (file:///C:/workspace/config/application-db.yaml) for profile db
    'file:/C:/workspace/config/application.yaml' (file:///C:/workspace/config/application.yaml) for profile db
    'file:/C:/workspace/config/snap.properties' (file:///C:/workspace/config/snap.properties) for profile git
    'file:/C:/workspace/config/snap-git.properties' (file:///C:/workspace/config/snap.properties) for profile git
    'file:/C:/workspace/config/snap-git.xml' (file:///C:/workspace/config/snap-git.xml) for profile git
    'file:/C:/workspace/config/snap-git.xml' (file:///C:/workspace/config/snap-git.xml) for profile git
    'file:/C:/workspace/config/snap-db.xml' (file:///C:/workspace/config/snap-db.xml) for profile git
    'file:/C:/workspace/config/snap.xml' (file:///C:/workspace/config/snap.xml) for profile git
    'file:/C:/workspace/config/snap-git.yml' (file:///C:/workspace/config/snap-git.yml) for profile git
    'file:/C:/workspace/config/snap-git.yml' (file:///C:/workspace/config/snap-git.yml) for profile git
    'file:/C:/workspace/config/snap-db.yml' (file:///C:/workspace/config/snap-db.yml) for profile git
    'file:/C:/workspace/config/snap.yml' (file:///C:/workspace/config/snap.yml) for profile git
    'file:/C:/workspace/config/snap-git.yaml' (file:///C:/workspace/config/snap-git.yaml) for profile git
    'file:/C:/workspace/config/snap-git.yaml' (file:///C:/workspace/config/snap-git.yaml) for profile git
    'file:/C:/workspace/config/snap-db.yaml' (file:///C:/workspace/config/snap-db.yaml) for profile git
    'file:/C:/workspace/config/snap.yaml' (file:///C:/workspace/config/snap.yaml) for profile git
    'file:/C:/workspace/config/application-git.properties' (file:///C:/workspace/config/application-git.properties) for profile git
    'file:/C:/workspace/config/application-git.properties' (file:///C:/workspace/config/application-git.properties) for profile git
    'file:/C:/workspace/config/application-db.properties' (file:///C:/workspace/config/application-db.properties) for profile git
    'file:/C:/workspace/config/application.properties' (file:///C:/workspace/config/application.properties) for profile git
    'file:/C:/workspace/config/application-git.xml' (file:///C:/workspace/config/application-git.xml) for profile git
    'file:/C:/workspace/config/application-git.xml' (file:///C:/workspace/config/application-git.xml) for profile git
    'file:/C:/workspace/config/application-db.xml' (file:///C:/workspace/config/application-db.xml) for profile git
    'file:/C:/workspace/config/application.xml' (file:///C:/workspace/config/application.xml) for profile git
    'file:/C:/workspace/config/application-git.yml' (file:///C:/workspace/config/application-git.yml) for profile git
    'file:/C:/workspace/config/application-git.yml' (file:///C:/workspace/config/application-git.yml) for profile git
    'file:/C:/workspace/config/application-db.yml' (file:///C:/workspace/config/application-db.yml) for profile git
    'file:/C:/workspace/config/application.yml' (file:///C:/workspace/config/application.yml) for profile git
    'file:/C:/workspace/config/application-git.yaml' (file:///C:/workspace/config/application-git.yaml) for profile git
    'file:/C:/workspace/config/application-git.yaml' (file:///C:/workspace/config/application-git.yaml) for profile git
    'file:/C:/workspace/config/application-db.yaml' (file:///C:/workspace/config/application-db.yaml) for profile git
    'file:/C:/workspace/config/application.yaml' (file:///C:/workspace/config/application.yaml) for profile git
    'file:/C:/workspace/config/snap.properties' (file:///C:/workspace/config/snap.properties)
    'file:/C:/workspace/config/snap.xml' (file:///C:/workspace/config/snap.xml)
    'file:/C:/workspace/config/snap.yml' (file:///C:/workspace/config/snap.yml)
    'file:/C:/workspace/config/snap.yaml' (file:///C:/workspace/config/snap.yaml)
    'file:/C:/workspace/config/application.properties' (file:///C:/workspace/config/application.properties)
    'file:/C:/workspace/config/application.xml' (file:///C:/workspace/config/application.xml)
    'file:/C:/workspace/config/application.yml' (file:///C:/workspace/config/application.yml)
    'file:/C:/workspace/config/application.yaml' (file:///C:/workspace/config/application.yaml)
```
