package org.jarvis.cloud.config.service;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.cloud.config.server.ConfigServerApplication;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ConfigServerApplicationTest {

	
	   @Test
	   public void testmain() {
		ConfigServerApplication.main(new String[] {});
	   }
}
