package com.bt.jarvis.persistence.util;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class Constants {

	
	private Constants() {
		
	}
	
	public static final String SUCCESS = "success";
	public static final String STATUS = "status";
	public static final String ERROR = "Task <{}> processing completed with Failed - statusCode: <{}>, statusMessage: <{}>, output: <{}>, Exception: <{}>";
	public static final String MESSAGE = "message";
	public static final String TIMESTAMP = "timestamp";
	public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	public static final String STATUS_FAILURE = "Failure";
	public static final String FAILURE_STATUS_CODE = "500";
	public static final String  isActive = "Y";
	public static final String SUCCESS_CODE="200";
	
	public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT);
	static {
		DATE_FORMATTER.setTimeZone(TimeZone.getTimeZone("UTC"));
	}
	
}
