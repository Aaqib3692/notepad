package com.bt.jarvis.persistence.service;

import com.bt.jarvis.persistence.response.TemplateResponse;

public interface TemplateService {

	TemplateResponse getTemplateData();
}
