
package com.bt.jarvis.persistence.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ProblemAttribute{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int problemAttributeId;
	private String  incidentCharkey;
	private String incidentCharValue;

	@JsonIgnore
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="problem_id")
	private Problem problem;

	public ProblemAttribute() {
		super();
	}

	public int getProblemAttributeId() {
		return problemAttributeId;
	}

	public void setProblemAttributeId(int problemAttributeId) {
		this.problemAttributeId = problemAttributeId;
	}

	public String getIncidentCharkey() {
		return incidentCharkey;
	}

	public void setIncidentCharkey(String incidentCharkey) {
		this.incidentCharkey = incidentCharkey;
	}

	public String getIncidentCharValue() {
		return incidentCharValue;
	}

	public void setIncidentCharValue(String incidentCharValue) {
		this.incidentCharValue = incidentCharValue;
	}

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

}
