package com.bt.jarvis.persistence.response;

public class Message {
	
	private  String ProblemId;

	public String getProblemId() {
		return ProblemId;
	}

	public void setProblemId(String problemId) {
		ProblemId = problemId;
	}


}
