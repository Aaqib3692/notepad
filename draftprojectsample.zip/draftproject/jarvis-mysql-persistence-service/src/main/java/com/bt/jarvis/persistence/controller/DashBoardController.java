package com.bt.jarvis.persistence.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bt.jarvis.persistence.response.DashBoardResponse;
import com.bt.jarvis.persistence.response.PieChartResponse;
import com.bt.jarvis.persistence.response.Response;
import com.bt.jarvis.persistence.service.DashBoardService;
import com.bt.jarvis.persistence.util.Constants;

@RestController
@RequestMapping("/dashboard")
@CrossOrigin(origins = "*")
public class DashBoardController extends BaseController {
	private static final Logger LOG = LoggerFactory.getLogger(DashBoardController.class);

	@Autowired
	DashBoardService dashBoardService;

	@GetMapping("/tabledata")
	public ResponseEntity<Response> getTableData() {
		long startTIme = System.currentTimeMillis();
		Response response = new Response();
		DashBoardResponse dashBoardResponse = null;
		try {
			dashBoardResponse = dashBoardService.getDashBoardData();
			setResponse(response, dashBoardResponse, Constants.SUCCESS, Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOG.debug("TOTAL_PROCESS_TIME taken by DashBoardController.getTableData "
				+ (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	
	
	@GetMapping("/piechartdata")
	public ResponseEntity<Response> getPieChartData() {
		long startTIme = System.currentTimeMillis();
		Response response = new Response();
		PieChartResponse pieChartResponse = null;
		try {
			pieChartResponse = dashBoardService.getPieChartData();
			setResponse(response, pieChartResponse, Constants.SUCCESS, Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOG.debug("TOTAL_PROCESS_TIME taken by DashBoardController.getPieChartData "
				+ (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

}
