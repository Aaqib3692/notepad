package com.bt.jarvis.persistence.controller;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bt.jarvis.persistence.entity.ARSolutionMap;
import com.bt.jarvis.persistence.entity.ActionReport;
import com.bt.jarvis.persistence.entity.Fallout;
import com.bt.jarvis.persistence.entity.Problem;
import com.bt.jarvis.persistence.entity.Resolution;
import com.bt.jarvis.persistence.repository.EquipmentDetailsRepository;
import com.bt.jarvis.persistence.response.Message;
import com.bt.jarvis.persistence.response.ResolutionResponse;
import com.bt.jarvis.persistence.response.Response;
import com.bt.jarvis.persistence.response.SearchListResposne;
import com.bt.jarvis.persistence.service.ProblemService;
import com.bt.jarvis.persistence.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "*")
public class ProblemController extends BaseController{
	
	private static final Logger log = LoggerFactory.getLogger(ProblemController.class);
	private static final long startTIme = System.currentTimeMillis();
	
	@Autowired
	EquipmentDetailsRepository equipmentDetailsRepository;

	@Autowired
	ProblemService service;

	@PostMapping("/saveRecord")
	public ResponseEntity<Response> saveProblem(@RequestBody Problem problem) {
		Message msg = new Message();
		Response response = new Response();
		try {
			String responseMsg = "";
			responseMsg = service.InsertRecord(problem);
			msg.setProblemId(responseMsg);
			setResponse(response, msg, Constants.SUCCESS, Constants.SUCCESS_CODE, "MANUAL FAULT- created");
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.saveProblem" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@GetMapping("/fetchRecord/{id}")
	public ResponseEntity<?> selectRecord(@PathVariable Long id) {
		Response response = new Response();
		try {
			Problem problem  = service.selectRecord(id);
			setResponse(response, problem, Constants.SUCCESS, Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.selectRecord" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@GetMapping("/searchRecords")
	public ResponseEntity<Response> searchRecords() {
		Response response=new Response();
		try {
			SearchListResposne list = service.searchRecords();
			setResponse(response,list, Constants.SUCCESS,Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.searchRecords " + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/updateRecord/{id}")
	public ResponseEntity<?> updateRecord(@PathVariable Long id, @RequestBody Problem updateProblem) {
		Response response=new Response();
		try {
			log.debug("ProblemController updateRecord start time " + System.currentTimeMillis());
			Map<String, Object> updateRecord= service.updateRecord(id, updateProblem);
			setResponse(response,updateRecord, Constants.SUCCESS,Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.updateRecord" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/inventoryJson")
	public ResponseEntity<?> selectInventoryJson(@RequestParam Long SneValue) throws JsonProcessingException {
		Response response=new Response();
		try {
			JSONObject selectInventoryJson = service.selectInventoryJson(SneValue);
			setResponse(response,selectInventoryJson, Constants.SUCCESS,Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.selectInventoryJson" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/updateActionReport/{id}")
	public ResponseEntity<?> updateActionReport(@PathVariable Long id, @RequestBody ActionReport updateReport) {
		Response response=new Response();
		try {
			log.debug("ProblemController updateActionReport start time " + System.currentTimeMillis());
			Map<String, Object> updateReportRecord =service.updateReportRecord(id, updateReport);
			setResponse(response,updateReportRecord, Constants.SUCCESS,Constants.SUCCESS_CODE, "Updating the status of Fault");
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.updateActionReport" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/saveActionReport")
	public ResponseEntity<?> saveActionReport(@RequestBody ActionReport saveReport) {
		Response response = new Response();
		try {
			Map<String, Object> saveReportRecord = service.saveReportRecord(saveReport);
			setResponse(response, saveReportRecord, Constants.SUCCESS, Constants.SUCCESS_CODE, "Saving data in Action Report");
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.saveActionReport"
				+ (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@PostMapping("/saveARMap")
	public ResponseEntity<?> saveArMap(@RequestBody ARSolutionMap arsolutionmap) {
		Response response = new Response();
		try {
			ARSolutionMap saveArMAp = service.saveArMAp(arsolutionmap);
			setResponse(response, saveArMAp, Constants.SUCCESS, Constants.SUCCESS_CODE, "Saving Record in ArMAPSplution");
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.saveArMap" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/saveFallout")
	public ResponseEntity<?> saveFallout(@RequestBody Fallout fallout) {
		Response response = new Response();
		try {
			Fallout saveFallout = service.saveFallout(fallout);
			setResponse(response, saveFallout, Constants.SUCCESS, Constants.SUCCESS_CODE, "Saving Record in Fallout");
		} catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("TOTAL_PROCESS_TIME taken by ProblemController.saveFallout" + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/searchIceCode/{ice}")
    public ResponseEntity<?> searchIecIdEuipType(@PathVariable Long ice,
                @RequestParam(defaultValue = "2") int pageNumber) {
		Response response = new Response();
          try {
        	  log.debug("ProblemController searchIecIdEuipType start time " + System.currentTimeMillis());
              ResolutionResponse searchIecIdEuipType = service.searchIecIdEuipType(ice, pageNumber);
        	  setResponse(response, searchIecIdEuipType, Constants.SUCCESS, Constants.SUCCESS_CODE, "Saving Record in Fallout");
          } catch (Exception e) {
			setResponse(response, null, Constants.STATUS_FAILURE, Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
          }
          log.debug("ProblemController searchIecIdEuipType finish time " + (System.currentTimeMillis() - startTIme));
      	return new ResponseEntity<>(response, HttpStatus.OK);
    }
	
	


}
