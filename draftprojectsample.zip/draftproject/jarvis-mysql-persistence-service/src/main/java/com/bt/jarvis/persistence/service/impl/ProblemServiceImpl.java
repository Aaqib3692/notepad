package com.bt.jarvis.persistence.service.impl;

import static com.bt.jarvis.persistence.util.Constants.ERROR;
import static com.bt.jarvis.persistence.util.Constants.isActive;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.jarvis.persistence.entity.ARSolutionMap;
import com.bt.jarvis.persistence.entity.ActionReport;
import com.bt.jarvis.persistence.entity.ActivityHistory;
import com.bt.jarvis.persistence.entity.EquipmentDetails;
import com.bt.jarvis.persistence.entity.Fallout;
import com.bt.jarvis.persistence.entity.Iec;
import com.bt.jarvis.persistence.entity.Problem;
import com.bt.jarvis.persistence.entity.ProblemAttribute;
import com.bt.jarvis.persistence.entity.ProblemNotes;
import com.bt.jarvis.persistence.entity.Resolution;
import com.bt.jarvis.persistence.repository.ARRepository;
import com.bt.jarvis.persistence.repository.ActionReportRepository;
import com.bt.jarvis.persistence.repository.ActivityHistoryRepository;
import com.bt.jarvis.persistence.repository.EquipmentDetailsRepository;
import com.bt.jarvis.persistence.repository.FalloutRepository;
import com.bt.jarvis.persistence.repository.IecRepository;
import com.bt.jarvis.persistence.repository.ProblemRepository;
import com.bt.jarvis.persistence.repository.ResolutionRepository;
import com.bt.jarvis.persistence.response.ResolutionResponse;
import com.bt.jarvis.persistence.response.SearchListResposne;
import com.bt.jarvis.persistence.response.SearchResponse;
import com.bt.jarvis.persistence.service.ProblemService;
import com.bt.jarvis.persistence.util.ServiceUtil;

@Service
public class ProblemServiceImpl implements ProblemService {
	private static final Logger log = LoggerFactory.getLogger(ProblemServiceImpl.class);

	@Autowired
	ProblemRepository problemRepository;

	@Autowired
	EquipmentDetailsRepository equipmentDetailsRepository;

	@Autowired
	ActionReportRepository actionReportRepository;

	@Autowired
	ResolutionRepository resolutionrepository;

	@Autowired
	ARRepository arrepository;

	@Autowired
	FalloutRepository falloutrepository;
	
	@Autowired
	ActivityHistoryRepository activityHistoryRepository;
	
	@Autowired
	IecRepository iecrepository;
	
   
	
	public String InsertRecord(Problem problem) {
		Date dateType = ServiceUtil.currDate();
		problem.setCreatedDate(dateType);
		problem.setModifyDate(dateType);
		
		Set<ProblemAttribute> problemAttribute = problem.getProblemAttribute();
		Set<ProblemAttribute> updatedProblemAttribute = new HashSet<>();

		for (ProblemAttribute problemAttributeObj : problemAttribute) {
			problemAttributeObj.setProblem(problem);
			updatedProblemAttribute.add(problemAttributeObj);
		}

		problem.setProblemAttribute(updatedProblemAttribute);
		Set<EquipmentDetails> equipment_Details = problem.getEquipmentDetails();
		Set<EquipmentDetails> updateEquipmentDetails = new HashSet<>();
		for (EquipmentDetails equipmentDetail : equipment_Details) {
			equipmentDetail.setProblem(problem);
			updateEquipmentDetails.add(equipmentDetail);
		}
		problem.setEquipmentDetails(updateEquipmentDetails);

		Set<ProblemNotes> problemNotes = problem.getProblemNotes();
		Set<ProblemNotes> updatedProblemNotes = new HashSet<>();
		for (ProblemNotes problemNotesObj : problemNotes) {
			problemNotesObj.setProblem(problem);
			updatedProblemNotes.add(problemNotesObj);
		}
		problem.setProblemAttribute(updatedProblemAttribute);
		problemRepository.save(problem);
		String data = problem.getProblemId().toString();
		
		ActivityHistory activityHistory = new ActivityHistory();
		activityHistory.setProblemId(problem.getProblemId());
		activityHistory.setProblemstatus(problem.getProblemStatus());
		activityHistoryRepository.save(activityHistory);
		
		return data;

	}

	public Map<String, Object> updateRecord(Long id, Problem updateProblem) {
		Optional<Problem> findById = problemRepository.findById(id);
		Problem equipment = findById.get();
		Set<EquipmentDetails> equiDetails = equipment.getEquipmentDetails();
		for (EquipmentDetails details : equiDetails) {
			details.setProcessKey(updateProblem.getProcessKey());
		}
		equipment.setProblemId(id);
		equipment.setProblemStatus(updateProblem.getProblemStatus());
		equipment.setProcessKey(updateProblem.getProcessKey());
		log.info("Saving the Problem and Equipment with updated values ");
		Problem updateProbObj = problemRepository.save(equipment);
		
		ActivityHistory activityHistory = new ActivityHistory();
		activityHistory.setProblemId(id);
		activityHistory.setProblemstatus(updateProblem.getProblemStatus());
		activityHistoryRepository.save(activityHistory);
		
		Map<String, Object> responseMap = new HashMap<String, Object>();
		responseMap.put("Problem", updateProbObj);
		return responseMap;

	}

	public Problem selectRecord(Long id) {
		Optional<Problem> findById = problemRepository.findById(id);
		Problem problem = findById.get();
		return problem;
	}

	public Map<String, Object> saveReportRecord(ActionReport saveReport) {
		ActionReport actionReportObj = actionReportRepository.save(saveReport);
		Map<String, Object> responseMap = new HashMap<String, Object>();
		responseMap.put("ActionReport", actionReportObj);
		return responseMap;
	}

	public Map<String, Object> updateReportRecord(Long id, ActionReport updateReport) {
		updateReport.setActionReportId(id);
		updateReport.setStatus(updateReport.getStatus());
		ActionReport actionReportObj = actionReportRepository.save(updateReport);
		Map<String, Object> responseMap = new HashMap<String, Object>();
		responseMap.put("ActionReport", actionReportObj);
		return responseMap;
	}

	public JSONObject selectInventoryJson(Long SneValue) {
		JSONParser parser = new JSONParser();
		JSONObject obj = null;
		try {
			String userHomeDir = System.getProperty("user.home");
			userHomeDir = userHomeDir + "/" + "test.json";
			log.info("userHomeDir---------->" + userHomeDir);
			FileReader reader = new FileReader(new File(userHomeDir));
			obj = (JSONObject) parser.parse(reader);
		} catch (Exception e) {
			log.error(ERROR, e.getMessage());
		}
		return obj;
	}

	public ARSolutionMap saveArMAp(ARSolutionMap arsolutionmap) {
		arrepository.save(arsolutionmap);
		Optional<ARSolutionMap> mapSolution = arrepository.findById(arsolutionmap.getArSolutionMapId());
		ARSolutionMap arsolutionmapResponse = mapSolution.get();
		return arsolutionmapResponse;
	}

	public Fallout saveFallout(Fallout fallout) {
		falloutrepository.save(fallout);
		Optional<Fallout> falloutRes = falloutrepository.findById(fallout.getFalloutId());
		Fallout falloutResponse = falloutRes.get();
		return falloutResponse;

	}

	public SearchListResposne searchRecords() {
		SearchListResposne searchResposne=new SearchListResposne();
		List<Problem> problems = problemRepository.findAll();
        List<SearchResponse> listRes=new ArrayList<SearchResponse>();
		
		for(Problem prob : problems) {
			SearchResponse response=new SearchResponse();
			response.setProblemId(prob.getProblemId());
			response.setProblemStatus(prob.getProblemStatus());
			response.setCreatedDate(prob.getCreatedDate());
			Set<ProblemAttribute> problemAttribute = prob.getProblemAttribute();
			for(ProblemAttribute attributes : problemAttribute) {
				if(attributes.getIncidentCharkey()!=null && attributes.getIncidentCharkey().equalsIgnoreCase("serviceAffectingFlag")){
					response.setServiceAffectingFlag(attributes.getIncidentCharValue());
				}else if(attributes.getIncidentCharkey()!=null && attributes.getIncidentCharkey().equalsIgnoreCase("level3Type")) {
				response.setLevel3Type(attributes.getIncidentCharValue());
				}else if (attributes.getIncidentCharkey() != null
						&& attributes.getIncidentCharkey().equalsIgnoreCase("equipAlarmCode")) {
					response.setLevel3Type(attributes.getIncidentCharValue());
				} else if (attributes.getIncidentCharkey() != null
						&& attributes.getIncidentCharkey().equalsIgnoreCase("project")) {
					response.setLevel3Type(attributes.getIncidentCharValue());
				} else if(attributes.getIncidentCharkey() != null
						&& attributes.getIncidentCharkey().equalsIgnoreCase("faultTypefaultType")) {
					response.setLevel3Type(attributes.getIncidentCharValue());
				}
			}
			Set<EquipmentDetails> equiDetails = prob.getEquipmentDetails();
			for (EquipmentDetails details : equiDetails) {
				response.setEquipType(details.getEqptType());
				response.setEquipment(details.getEquipment());
				response.setEhnm(details.getEhnm());
				response.setPtpnm(details.getPtpnm());
				response.setCode(details.getCode_1141());
			}
			listRes.add(response);
		
		}
		searchResposne.setListSearchResponse(listRes);
		return searchResposne;
	}
	
	
    public ResolutionResponse searchIecIdEuipType(Long iceId, int pageNumber) {
    	ResolutionResponse response=new ResolutionResponse();
          Optional<Iec> iec = iecrepository.findById(iceId);
          Iec iecRecord = iec.get();
          String iceCode=iecRecord.getIecCode();
          String criteria = iecRecord.getCriteria();
          String[] split = criteria.split(",");
          String euipType = split[3];   
          List<Resolution> resolution = resolutionrepository.findByCriteriaContainingAndCriteriaContainingAndIsactive(euipType, iceCode, isActive);
          response.setResolution(resolution.get(0));
          response.setEquipType(euipType);
          response.setIecCode(iceCode); 
          return response;
    }

}
