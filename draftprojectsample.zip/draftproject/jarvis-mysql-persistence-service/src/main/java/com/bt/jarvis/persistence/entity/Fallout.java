
package com.bt.jarvis.persistence.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;


@Entity
public class Fallout { 
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long falloutId;
	private Long problemId;
	private String status;
	private Long actionReportId;
	private String falloutCode;
	
	public Long getFalloutId() {
		return falloutId;
	}
	public void setFalloutId(Long falloutId) {
		this.falloutId = falloutId;
	}
	public Long getProblemId() {
		return problemId;
	}
	public void setProblemId(Long problemId) {
		this.problemId = problemId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getActionReportId() {
		return actionReportId;
	}
	public void setActionReportId(Long actionReportId) {
		this.actionReportId = actionReportId;
	}
	public String getFalloutCode() {
		return falloutCode;
	}
	public void setFalloutCode(String falloutCode) {
		this.falloutCode = falloutCode;
	}
	
	@Override
	public String toString() {
		return "Fallout [falloutId=" + falloutId + ", problemId=" + problemId + ", status=" + status
				+ ", actionReportId=" + actionReportId + ", falloutCode=" + falloutCode + "]";
	}
	
}
