package com.bt.jarvis.persistence.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PieChart {
	
	private String name;
	
	private String label;
	
	@JsonProperty("y")
	private String year;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	
	
	
	
	

}
