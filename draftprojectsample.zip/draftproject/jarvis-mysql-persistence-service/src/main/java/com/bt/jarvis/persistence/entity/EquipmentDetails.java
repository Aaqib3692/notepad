
package com.bt.jarvis.persistence.entity;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("serial")
@Entity
@Table(name="equipment_details")
public class EquipmentDetails implements java.io.Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long equipmentDetailsId;
	private String code_1141;
	private String mdnm;
	private String ehnm;
	private String ptpnm;
	private String eqptType;
	private Long equipment;
	private String processKey;
	
	@Transient
	private Long problem_id;
	
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="problem_id")
	@JsonIgnore
	private Problem problem;

	public EquipmentDetails() {
		super();
	}

	public Long getEquipmentDetailsId() {
		return equipmentDetailsId;
	}

	public void setEquipmentDetailsId(Long equipmentDetailsId) {
		this.equipmentDetailsId = equipmentDetailsId;
	}

	public String getCode_1141() {
		return code_1141;
	}

	public void setCode_1141(String code_1141) {
		this.code_1141 = code_1141;
	}

	public String getMdnm() {
		return mdnm;
	}

	public void setMdnm(String mdnm) {
		this.mdnm = mdnm;
	}

	public String getEhnm() {
		return ehnm;
	}

	public void setEhnm(String ehnm) {
		this.ehnm = ehnm;
	}

	public String getPtpnm() {
		return ptpnm;
	}

	public void setPtpnm(String ptpnm) {
		this.ptpnm = ptpnm;
	}

	public String getEqptType() {
		return eqptType;
	}

	public void setEqptType(String eqptType) {
		this.eqptType = eqptType;
	}

	public Long getEquipment() {
		return equipment;
	}

	public void setEquipment(Long equipment) {
		this.equipment = equipment;
	}

	public String getProcessKey() {
		return processKey;
	}

	public void setProcessKey(String processKey) {
		this.processKey = processKey;
	}

	public Long getProblem_id() {
		return problem_id;
	}

	public void setProblem_id(Long problem_id) {
		this.problem_id = problem_id;
	}

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	
	
}
