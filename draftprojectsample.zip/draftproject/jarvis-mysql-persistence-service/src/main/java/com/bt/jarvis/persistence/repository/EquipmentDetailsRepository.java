package com.bt.jarvis.persistence.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bt.jarvis.persistence.entity.EquipmentDetails;


@Repository
public interface EquipmentDetailsRepository extends JpaRepository<EquipmentDetails, Long>{
	List<EquipmentDetails> findByEquipment(Long equipment);
	
}
