package com.bt.jarvis.persistence.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bt.jarvis.persistence.response.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BaseController {

	private static final Logger LOG = LoggerFactory.getLogger(BaseController.class);

	public void setResponse(Response response, Object responseData, String status, String statusCode, String message) {
		long startTime = System.currentTimeMillis();
		response.setResponseData(responseData);
		response.setStatus(status);
		response.setStatusCode(statusCode);
		response.setMessage(message);
		if (LOG.isDebugEnabled()) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				LOG.debug(mapper.writeValueAsString(response));
			} catch (JsonProcessingException e) {
				LOG.error("Error in writing object as string : " + e);
			}
		}
		LOG.info("TOTAL_PROCESS_TIME taken by BaseController.setResponse: " + (System.currentTimeMillis() - startTime));
	}
}
