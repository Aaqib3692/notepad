package com.bt.jarvis.persistence.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bt.jarvis.persistence.entity.Iec;

@Repository
public interface IecRepository extends PagingAndSortingRepository<Iec,Long>{

	Optional<Iec> findById(Long iceId);
	
	
	

}
