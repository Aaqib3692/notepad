package com.bt.jarvis.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Iec {

	@Id
	private Long iecId;
	private String iecCode;
	private String criteria;
	private String status;
	@Column(name="serviceaffectingflag")
	private String isServiceAffecting;
	private String eeFlag;
	
	public Long getIecId() {
		return iecId;
	}
	public void setIecId(Long iecId) {
		this.iecId = iecId;
	}
	public String getIecCode() {
		return iecCode;
	}
	public void setIecCode(String iecCode) {
		this.iecCode = iecCode;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsServiceAffecting() {
		return isServiceAffecting;
	}
	public void setIsServiceAffecting(String isServiceAffecting) {
		this.isServiceAffecting = isServiceAffecting;
	}
	public String getEeFlag() {
		return eeFlag;
	}
	public void setEeFlag(String eeFlag) {
		this.eeFlag = eeFlag;
	}
	
	 

}
