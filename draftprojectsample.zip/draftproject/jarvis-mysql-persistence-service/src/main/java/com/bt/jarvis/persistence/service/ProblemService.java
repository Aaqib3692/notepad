package com.bt.jarvis.persistence.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import com.bt.jarvis.persistence.entity.ARSolutionMap;
import com.bt.jarvis.persistence.entity.ActionReport;
import com.bt.jarvis.persistence.entity.Fallout;
import com.bt.jarvis.persistence.entity.Problem;
import com.bt.jarvis.persistence.entity.Resolution;
import com.bt.jarvis.persistence.response.ResolutionResponse;
import com.bt.jarvis.persistence.response.SearchListResposne;

public interface ProblemService {

	String InsertRecord(Problem problem);

	Problem selectRecord(Long id);

	SearchListResposne searchRecords();

	Map<String, Object> updateRecord(Long id, Problem updateProblem);

	JSONObject selectInventoryJson(Long sneValue);

	Map<String, Object> updateReportRecord(Long id, ActionReport updateReport);

	Map<String, Object> saveReportRecord(ActionReport saveReport);

	ARSolutionMap saveArMAp(ARSolutionMap arsolutionmap);

	Fallout saveFallout(Fallout fallout);
	
	ResolutionResponse searchIecIdEuipType(Long iceId, int pageNumber);

}
