package com.bt.jarvis.persistence.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bt.jarvis.persistence.response.AssociateDiagnostics;
import com.bt.jarvis.persistence.response.Cards;
import com.bt.jarvis.persistence.response.CloseData;
import com.bt.jarvis.persistence.response.DashBoardResponse;
import com.bt.jarvis.persistence.response.DesignSolution;
import com.bt.jarvis.persistence.response.ImplementSolution;
import com.bt.jarvis.persistence.response.New;
import com.bt.jarvis.persistence.response.PieChart;
import com.bt.jarvis.persistence.response.PieChartResponse;
import com.bt.jarvis.persistence.service.DashBoardService;

@Service
public class DashBoardServiceImpl implements DashBoardService {

	@Override
	public DashBoardResponse getDashBoardData() {
		// TODO Auto-generated method stub
		DashBoardResponse dashBoardResponse = new DashBoardResponse();
		List<New> newList = new ArrayList<New>();
		List<CloseData> closeDataList = new ArrayList<CloseData>();
		List<DesignSolution> designListData = new ArrayList<DesignSolution>();
		List<ImplementSolution> implSolListData = new ArrayList<ImplementSolution>();
		List<AssociateDiagnostics> assDiaListData = new ArrayList<AssociateDiagnostics>();
		New newdata = new New();
		newdata.setComments("Test Dashboard");
		newdata.setOwner("Praveen");
		newdata.setProblemId("125");

		New newdata1 = new New();
		newdata1.setComments("Test Dashboard");
		newdata1.setOwner("Praveen");
		newdata1.setProblemId("126");

		New newdata2 = new New();
		newdata2.setComments("Test Dashboard");
		newdata2.setOwner("Praveen");
		newdata2.setProblemId("127");

		New newdata3 = new New();
		newdata3.setComments("Test Dashboard");
		newdata3.setOwner("Praveen");
		newdata3.setProblemId("128");

		New newdata4 = new New();
		newdata4.setComments("Test Dashboard");
		newdata4.setOwner("Praveen");
		newdata4.setProblemId("129");

		New newdata5 = new New();
		newdata5.setComments("Test Dashboard");
		newdata5.setOwner("Praveen");
		newdata5.setProblemId("130");

		New newdata6 = new New();
		newdata6.setComments("Test Dashboard");
		newdata6.setOwner("Praveen");
		newdata6.setProblemId("131");

		newList.add(newdata);
		newList.add(newdata1);
		newList.add(newdata2);
		newList.add(newdata3);
		newList.add(newdata4);
		newList.add(newdata5);
		newList.add(newdata6);

		CloseData problemdata = new CloseData();
		problemdata.setComments("Test Dashboard");
		problemdata.setOwner("Deepti");
		problemdata.setProblemId("132");

		CloseData problemdata1 = new CloseData();
		problemdata1.setComments("Test Dashboard");
		problemdata1.setOwner("Deepti");
		problemdata1.setProblemId("133");

		CloseData problemdata2 = new CloseData();
		problemdata2.setComments("Test Dashboard");
		problemdata2.setOwner("Deepti");
		problemdata2.setProblemId("134");

		CloseData problemdata3 = new CloseData();
		problemdata3.setComments("Test Dashboard");
		problemdata3.setOwner("Deepti");
		problemdata3.setProblemId("135");

		CloseData problemdata4 = new CloseData();
		problemdata4.setComments("Test Dashboard");
		problemdata4.setOwner("Deepti");
		problemdata4.setProblemId("136");

		CloseData problemdata5 = new CloseData();
		problemdata5.setComments("Test Dashboard");
		problemdata5.setOwner("Deepti");
		problemdata5.setProblemId("137");

		CloseData problemdata6 = new CloseData();
		problemdata6.setComments("Test Dashboard");
		problemdata6.setOwner("Deepti");
		problemdata6.setProblemId("138");

		closeDataList.add(problemdata);
		closeDataList.add(problemdata1);
		closeDataList.add(problemdata2);
		closeDataList.add(problemdata3);
		closeDataList.add(problemdata4);
		closeDataList.add(problemdata5);
		closeDataList.add(problemdata6);

		DesignSolution designdata = new DesignSolution();
		designdata.setComments("Test Dashboard");
		designdata.setOwner("Raghu");
		designdata.setProblemId("139");

		DesignSolution designdata1 = new DesignSolution();
		designdata1.setComments("Test Dashboard");
		designdata1.setOwner("Raghu");
		designdata1.setProblemId("140");

		DesignSolution designdata2 = new DesignSolution();
		designdata2.setComments("Test Dashboard");
		designdata2.setOwner("Raghu");
		designdata2.setProblemId("141");

		DesignSolution designdata3 = new DesignSolution();
		designdata3.setComments("Test Dashboard");
		designdata3.setOwner("Raghu");
		designdata3.setProblemId("142");

		DesignSolution designdata4 = new DesignSolution();
		designdata4.setComments("Test Dashboard");
		designdata4.setOwner("Raghu");
		designdata4.setProblemId("143");

		DesignSolution designdata5 = new DesignSolution();
		designdata5.setComments("Test Dashboard");
		designdata5.setOwner("Raghu");
		designdata5.setProblemId("144");

		DesignSolution designdata6 = new DesignSolution();
		designdata6.setComments("Test Dashboard");
		designdata6.setOwner("Raghu");
		designdata6.setProblemId("145");

		designListData.add(designdata);
		designListData.add(designdata1);
		designListData.add(designdata2);
		designListData.add(designdata3);
		designListData.add(designdata4);
		designListData.add(designdata5);
		designListData.add(designdata6);

		ImplementSolution implSolutionData = new ImplementSolution();
		implSolutionData.setComments("Test Dashboard");
		implSolutionData.setOwner("Hetal");
		implSolutionData.setProblemId("146");

		ImplementSolution implSolutionData1 = new ImplementSolution();
		implSolutionData1.setComments("Test Dashboard");
		implSolutionData1.setOwner("Hetal");
		implSolutionData1.setProblemId("147");

		ImplementSolution implSolutionData2 = new ImplementSolution();
		implSolutionData2.setComments("Test Dashboard");
		implSolutionData2.setOwner("Hetal");
		implSolutionData2.setProblemId("148");

		ImplementSolution implSolutionData3 = new ImplementSolution();
		implSolutionData3.setComments("Test Dashboard");
		implSolutionData3.setOwner("Hetal");
		implSolutionData3.setProblemId("149");

		ImplementSolution implSolutionData4 = new ImplementSolution();
		implSolutionData4.setComments("Test Dashboard");
		implSolutionData4.setOwner("Hetal");
		implSolutionData4.setProblemId("150");

		ImplementSolution implSolutionData5 = new ImplementSolution();
		implSolutionData5.setComments("Test Dashboard");
		implSolutionData5.setOwner("Hetal");
		implSolutionData5.setProblemId("151");

		ImplementSolution implSolutionData6 = new ImplementSolution();
		implSolutionData6.setComments("Test Dashboard");
		implSolutionData6.setOwner("Hetal");
		implSolutionData6.setProblemId("152");

		implSolListData.add(implSolutionData);
		implSolListData.add(implSolutionData1);
		implSolListData.add(implSolutionData2);
		implSolListData.add(implSolutionData3);
		implSolListData.add(implSolutionData4);
		implSolListData.add(implSolutionData5);
		implSolListData.add(implSolutionData6);

		AssociateDiagnostics assDiagnosticsData = new AssociateDiagnostics();
		assDiagnosticsData.setComments("Test Dashboard");
		assDiagnosticsData.setOwner("Prince");
		assDiagnosticsData.setProblemId("153");

		AssociateDiagnostics assDiagnosticsData1 = new AssociateDiagnostics();
		assDiagnosticsData1.setComments("Test Dashboard");
		assDiagnosticsData1.setOwner("Prince");
		assDiagnosticsData1.setProblemId("154");

		AssociateDiagnostics assDiagnosticsData2 = new AssociateDiagnostics();
		assDiagnosticsData2.setComments("Test Dashboard");
		assDiagnosticsData2.setOwner("Prince");
		assDiagnosticsData2.setProblemId("155");

		AssociateDiagnostics assDiagnosticsData3 = new AssociateDiagnostics();
		assDiagnosticsData3.setComments("Test Dashboard");
		assDiagnosticsData3.setOwner("Prince");
		assDiagnosticsData3.setProblemId("156");

		AssociateDiagnostics assDiagnosticsData4 = new AssociateDiagnostics();
		assDiagnosticsData4.setComments("Test Dashboard");
		assDiagnosticsData4.setOwner("Prince");
		assDiagnosticsData4.setProblemId("157");

		AssociateDiagnostics assDiagnosticsData5 = new AssociateDiagnostics();
		assDiagnosticsData5.setComments("Test Dashboard");
		assDiagnosticsData5.setOwner("Prince");
		assDiagnosticsData5.setProblemId("158");

		AssociateDiagnostics assDiagnosticsData6 = new AssociateDiagnostics();
		assDiagnosticsData6.setComments("Test Dashboard");
		assDiagnosticsData6.setOwner("Prince");
		assDiagnosticsData6.setProblemId("159");

		assDiaListData.add(assDiagnosticsData);
		assDiaListData.add(assDiagnosticsData1);
		assDiaListData.add(assDiagnosticsData2);
		assDiaListData.add(assDiagnosticsData3);
		assDiaListData.add(assDiagnosticsData4);
		assDiaListData.add(assDiagnosticsData5);
		assDiaListData.add(assDiagnosticsData6);
		dashBoardResponse.setCloseData(closeDataList);
		dashBoardResponse.setNewd(newList);
		dashBoardResponse.setDesignSolution(designListData);
		dashBoardResponse.setImplementSolution(implSolListData);
		dashBoardResponse.setAssociateDiagnostics(assDiaListData);
		return dashBoardResponse;
	}

	@Override
	public PieChartResponse getPieChartData() {
		// TODO Auto-generated method stub
		PieChartResponse pieChartResponse = new PieChartResponse();
		List<PieChart> listPieChartData = new ArrayList<PieChart>();

		PieChart newPieChart = new PieChart();
		newPieChart.setName("New");
		newPieChart.setLabel("New");
		newPieChart.setYear("5");

		PieChart adPieChart = new PieChart();
		adPieChart.setName("AD");
		adPieChart.setLabel("Associate and Diagnostics");
		adPieChart.setYear("20");

		PieChart dsPieChart = new PieChart();
		dsPieChart.setName("DS");
		dsPieChart.setLabel("Design Solution");
		dsPieChart.setYear("15");

		PieChart isPieChart = new PieChart();
		isPieChart.setName("IS");
		isPieChart.setLabel("Implement Solution");
		isPieChart.setYear("50");

		PieChart ccPieChart = new PieChart();
		ccPieChart.setName("cancel/closed");
		ccPieChart.setLabel("cancel/closed");
		ccPieChart.setYear("10");
		listPieChartData.add(newPieChart);
		listPieChartData.add(adPieChart);
		listPieChartData.add(dsPieChart);
		listPieChartData.add(isPieChart);
		listPieChartData.add(ccPieChart);
		Cards cards = new Cards();
		cards.setCritical("0");
		cards.setMajor("20");
		cards.setNewProblem("20");

		pieChartResponse.setPieChart(listPieChartData);
		pieChartResponse.setCards(cards);
		return pieChartResponse;
	}

}
