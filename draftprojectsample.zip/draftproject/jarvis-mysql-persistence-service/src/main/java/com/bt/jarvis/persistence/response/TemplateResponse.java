package com.bt.jarvis.persistence.response;

import java.util.List;

public class TemplateResponse {
	
	private List<TemplateData> templateData;

	public List<TemplateData> getTemplateData() {
		return templateData;
	}

	public void setTemplateData(List<TemplateData> templateData) {
		this.templateData = templateData;
	}

}
