package com.bt.jarvis.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bt.jarvis.persistence.entity.ARSolutionMap;

public interface ARRepository extends JpaRepository<ARSolutionMap, Long>{
	
	

}
