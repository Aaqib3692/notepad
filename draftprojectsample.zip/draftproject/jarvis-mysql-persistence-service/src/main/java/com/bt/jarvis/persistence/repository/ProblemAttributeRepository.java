package com.bt.jarvis.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bt.jarvis.persistence.entity.ProblemAttribute;


@Repository
public interface ProblemAttributeRepository  extends JpaRepository<ProblemAttribute, Long>{

}
