package com.bt.jarvis.persistence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class ActionReport{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long actionReportId;
	private String status;
	
	
	
	public Long getActionReportId() {
		return actionReportId;
	}
	public void setActionReportId(Long actionReportId) {
		this.actionReportId = actionReportId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
