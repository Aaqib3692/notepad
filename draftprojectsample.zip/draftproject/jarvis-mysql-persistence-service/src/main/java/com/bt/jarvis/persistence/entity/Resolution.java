package com.bt.jarvis.persistence.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Resolution {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long resolutionId;
	private Long solutionId;
	private String action;
	private String resolutionDesc;
	private String isactive;
	private String sequence;
	private Long linkedCount;
	private Long relevance;
	private Long unlinkedCount;
	private String product;
	private Date createDate;
	private Date modifiedDate;
	private String criteria;	
	private String resolutionTitle;
	
	
	public Long getResolutionId() {
		return resolutionId;
	}
	public void setResolutionId(Long resolutionId) {
		this.resolutionId = resolutionId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getResolutionDesc() {
		return resolutionDesc;
	}
	public void setResolutionDesc(String resolutionDesc) {
		this.resolutionDesc = resolutionDesc;
	}
	public String getIsactive() {
		return isactive;
	}
	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public Long getLinkedCount() {
		return linkedCount;
	}
	public void setLinkedCount(Long linkedCount) {
		this.linkedCount = linkedCount;
	}
	public Long getRelevance() {
		return relevance;
	}
	public void setRelevance(Long relevance) {
		this.relevance = relevance;
	}
	public Long getUnlinkedCount() {
		return unlinkedCount;
	}
	public void setUnlinkedCount(Long unlinkedCount) {
		this.unlinkedCount = unlinkedCount;
	}
	public Long getSolutionId() {
		return solutionId;
	}
	public void setSolutionId(Long solutionId) {
		this.solutionId = solutionId;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getResolutionTitle() {
		return resolutionTitle;
	}
	public void setResolutionTitle(String resolutionTitle) {
		this.resolutionTitle = resolutionTitle;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}


}
