package com.bt.jarvis.persistence.response;

import com.bt.jarvis.persistence.entity.Resolution;

public class ResolutionResponse {
	
	private String iecCode;
	private String equipType;
	private Resolution resolution;
	
	public String getIecCode() {
		return iecCode;
	}
	public void setIecCode(String iecCode) {
		this.iecCode = iecCode;
	}
	public String getEquipType() {
		return equipType;
	}
	public void setEquipType(String equipType) {
		this.equipType = equipType;
	}
	public Resolution getResolution() {
		return resolution;
	}
	public void setResolution(Resolution resolution) {
		this.resolution = resolution;
	}
	

}
