package com.bt.jarvis.persistence.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bt.jarvis.persistence.entity.ActivityHistory;

public interface ActivityHistoryRepository extends JpaRepository<ActivityHistory, Long>{

}
