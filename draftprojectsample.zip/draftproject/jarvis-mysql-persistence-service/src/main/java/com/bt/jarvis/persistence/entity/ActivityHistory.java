package com.bt.jarvis.persistence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ActivityHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long activityHistoryId;
	private Long problemId;
	private String problemstatus;
	
	public Long getActivityHistoryId() {
		return activityHistoryId;
	}
	public void setActivityHistoryId(Long activityHistoryId) {
		this.activityHistoryId = activityHistoryId;
	}
	public Long getProblemId() {
		return problemId;
	}
	public void setProblemId(Long problemId) {
		this.problemId = problemId;
	}
	public String getProblemstatus() {
		return problemstatus;
	}
	public void setProblemstatus(String problemstatus) {
		this.problemstatus = problemstatus;
	}
	
	
	
	
}
