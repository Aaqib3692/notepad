package com.bt.jarvis.persistence.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ServiceUtil {
	
	static Logger log =LoggerFactory.getLogger(ServiceUtil.class);

	private ServiceUtil() {
	}

	public static JsonNode respondWithErrorMessage(HttpStatus status, String message) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode response = mapper.createObjectNode();
		response.put(Constants.TIMESTAMP, Constants.DATE_FORMATTER.format(new Date()));
		response.put(Constants.STATUS, status.value());
		response.put(Constants.ERROR, status.getReasonPhrase());
		response.put(Constants.MESSAGE, message);
		return response;
	}
	

	public static String getExpectedDate(int days) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, days);
		Date tomorrow = calendar.getTime();
		return tomorrow.toString();
	}
	
	public static Date currDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String d = dateFormat.format(date);
		Date dateType = null;
		try {
			dateType = dateFormat.parse(d);
		} catch (ParseException e) {
			log.error("Error while inserting Record:"+e);
		}
		return dateType;
	}
	
	
}
