package com.bt.jarvis.persistence.response;

import java.util.List;

public class SearchListResposne {
	
	private List<SearchResponse> listSearchResponse;

	public List<SearchResponse> getListSearchResponse() {
		return listSearchResponse;
	}

	public void setListSearchResponse(List<SearchResponse> listSearchResponse) {
		this.listSearchResponse = listSearchResponse;
	}
	
	
	
	
	

}
