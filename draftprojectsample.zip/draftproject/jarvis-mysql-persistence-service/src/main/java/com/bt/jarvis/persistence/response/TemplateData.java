package com.bt.jarvis.persistence.response;

import java.util.List;

public class TemplateData {

	private String templateName;

	private String templateID;

	private List<TempAttributes> tempAttributes;

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public List<TempAttributes> getTempAttributes() {
		return tempAttributes;
	}

	public void setTempAttributes(List<TempAttributes> tempAttributes) {
		this.tempAttributes = tempAttributes;
	}

}
