package com.bt.jarvis.persistence.service;

import com.bt.jarvis.persistence.response.DashBoardResponse;
import com.bt.jarvis.persistence.response.PieChartResponse;

public interface DashBoardService {

	DashBoardResponse getDashBoardData();

	PieChartResponse getPieChartData();
}
