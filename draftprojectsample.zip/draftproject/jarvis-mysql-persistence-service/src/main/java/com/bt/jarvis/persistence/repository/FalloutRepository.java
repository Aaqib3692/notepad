package com.bt.jarvis.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bt.jarvis.persistence.entity.Fallout;

@Repository
public interface FalloutRepository extends JpaRepository<Fallout, Long> {

}
