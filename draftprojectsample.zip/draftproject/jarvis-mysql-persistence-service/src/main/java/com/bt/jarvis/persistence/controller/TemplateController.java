package com.bt.jarvis.persistence.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bt.jarvis.persistence.response.Response;
import com.bt.jarvis.persistence.response.TemplateResponse;
import com.bt.jarvis.persistence.service.TemplateService;
import com.bt.jarvis.persistence.util.Constants;

@RestController
@RequestMapping("/template")
@CrossOrigin(origins = "*")
public class TemplateController extends BaseController {
	private static final Logger LOG = LoggerFactory.getLogger(TemplateController.class);

	@Autowired
	TemplateService templateService;

	@GetMapping("/templatedata")
	public ResponseEntity<Response> selectTemplateWithData() {
		//LOG.debug("TemplateController selectTemplateWithData start time " + System.currentTimeMillis());
		long startTIme = System.currentTimeMillis();
		Response response=new Response();
		TemplateResponse templateResponse = null;
		try {
			templateResponse = templateService.getTemplateData();
			setResponse(response,templateResponse, Constants.SUCCESS,Constants.SUCCESS_CODE, null);
		} catch (Exception e) {
			setResponse(response,null, Constants.STATUS_FAILURE,Constants.FAILURE_STATUS_CODE, e.getMessage());
			return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOG.debug("TOTAL_PROCESS_TIME taken by TemplateController.selectTemplateWithData " + (System.currentTimeMillis() - startTIme));
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

}
