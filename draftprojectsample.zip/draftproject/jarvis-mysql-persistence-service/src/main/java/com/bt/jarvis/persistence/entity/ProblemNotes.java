package com.bt.jarvis.persistence.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ProblemNotes {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int notesId;
	private String notes;
	
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="problem_id")
	@JsonIgnore
	private Problem problem;
	
	public ProblemNotes() {
		super();
	}

	public int getNotesId() {
		return notesId;
	}

	public void setNotesId(int notesId) {
		this.notesId = notesId;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	
}
