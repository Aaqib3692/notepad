package com.bt.jarvis.persistence.response;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bt.jarvis.persistence.entity.ProblemAttribute;

public class SearchResponse {
	private Long problemId;
	private String problemStatus;
	private Date createdDate;
	private String equipType;
	private Long equipment;
	private String ehnm;
	private String ptpnm;
	private String code;
	//private Map attributeValues;
	private String level3Type;
	private String serviceAffectingFlag;
	
	public Long getProblemId() {
		return problemId;
	}
	public void setProblemId(Long problemId) {
		this.problemId = problemId;
	}
	public String getProblemStatus() {
		return problemStatus;
	}
	public void setProblemStatus(String problemStatus) {
		this.problemStatus = problemStatus;
	}
	public String getEquipType() {
		return equipType;
	}
	public void setEquipType(String equipType) {
		this.equipType = equipType;
	}
	
	public Long getEquipment() {
		return equipment;
	}
	public void setEquipment(Long equipment) {
		this.equipment = equipment;
	}
	public String getEhnm() {
		return ehnm;
	}
	public void setEhnm(String ehnm) {
		this.ehnm = ehnm;
	}
	public String getPtpnm() {
		return ptpnm;
	}
	public void setPtpnm(String ptpnm) {
		this.ptpnm = ptpnm;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	/*
	 * public Map getAttributeValues() { return attributeValues; } public void
	 * setAttributeValues(Map attributeValues) { this.attributeValues =
	 * attributeValues; }
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getLevel3Type() {
		return level3Type;
	}
	public void setLevel3Type(String level3Type) {
		this.level3Type = level3Type;
	}
	public String getServiceAffectingFlag() {
		return serviceAffectingFlag;
	}
	public void setServiceAffectingFlag(String serviceAffectingFlag) {
		this.serviceAffectingFlag = serviceAffectingFlag;
	}
	
	
	
	
	
}
