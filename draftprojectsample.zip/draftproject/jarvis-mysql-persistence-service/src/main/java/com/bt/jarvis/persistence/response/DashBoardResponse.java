package com.bt.jarvis.persistence.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DashBoardResponse {

	@JsonProperty("New")
	private List<New> newd;

	@JsonProperty("cancel/closed")
	private List<CloseData> closeData;
	
	@JsonProperty("Design Solution")
	private List<DesignSolution> designSolution;
	
	@JsonProperty("Implement Solution")
	private List<ImplementSolution> implementSolution;
	
	@JsonProperty("Associate and Diagnostics")
	private List<AssociateDiagnostics> associateDiagnostics;

	public List<New> getNewd() {
		return newd;
	}

	public void setNewd(List<New> newd) {
		this.newd = newd;
	}

	public List<CloseData> getCloseData() {
		return closeData;
	}

	public void setCloseData(List<CloseData> closeData) {
		this.closeData = closeData;
	}

	public List<DesignSolution> getDesignSolution() {
		return designSolution;
	}

	public void setDesignSolution(List<DesignSolution> designSolution) {
		this.designSolution = designSolution;
	}

	public List<ImplementSolution> getImplementSolution() {
		return implementSolution;
	}

	public void setImplementSolution(List<ImplementSolution> implementSolution) {
		this.implementSolution = implementSolution;
	}

	public List<AssociateDiagnostics> getAssociateDiagnostics() {
		return associateDiagnostics;
	}

	public void setAssociateDiagnostics(List<AssociateDiagnostics> associateDiagnostics) {
		this.associateDiagnostics = associateDiagnostics;
	}
	
	

}
