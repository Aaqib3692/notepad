package com.bt.jarvis.persistence.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Cards {

	@JsonProperty("Total TT")
	private String newProblem;

	@JsonProperty("Manual TT")
	private String major;

	@JsonProperty("Auto TT")
	private String critical;

	public String getNewProblem() {
		return newProblem;
	}

	public void setNewProblem(String newProblem) {
		this.newProblem = newProblem;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getCritical() {
		return critical;
	}

	public void setCritical(String critical) {
		this.critical = critical;
	}

}
