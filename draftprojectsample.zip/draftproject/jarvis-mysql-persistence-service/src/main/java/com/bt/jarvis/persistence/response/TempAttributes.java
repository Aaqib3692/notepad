package com.bt.jarvis.persistence.response;

import java.util.List;

public class TempAttributes {

	private String attributeName;
	
	private String attributeType;
	
	private boolean isReadable;
	
	private String  attributeValue;
	
	private List<DropDownLabelValue> listAttributeValue;

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeType() {
		return attributeType;
	}

	public void setAttributeType(String attributeType) {
		this.attributeType = attributeType;
	}


	public boolean isReadable() {
		return isReadable;
	}

	public void setReadable(boolean isReadable) {
		this.isReadable = isReadable;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public List<DropDownLabelValue> getListAttributeValue() {
		return listAttributeValue;
	}

	public void setListAttributeValue(List<DropDownLabelValue> listAttributeValue) {
		this.listAttributeValue = listAttributeValue;
	}

	
	


}
