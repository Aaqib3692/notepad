package com.bt.jarvis.persistence.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;


@Entity
public class Problem{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)	
	private Long problemId;
	private String sourceIdentifier;	
	private String processKey;
	private String problemStatus;	
	private Date createdDate;
	private Date modifyDate;
	private String probRef;
	
	@OneToMany(mappedBy = "problem", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<ProblemAttribute> problemAttribute;


	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "problem")
	private Set<EquipmentDetails> equipmentDetails;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "problem")
	private Set<ProblemNotes> problemNotes;
	
	public Problem() {
		super();
	}

	public Long getProblemId() {
		return problemId;
	}

	public void setProblemId(Long problemId) {
		this.problemId = problemId;
	}

	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	public String getProcessKey() {
		return processKey;
	}

	public void setProcessKey(String processKey) {
		this.processKey = processKey;
	}

	public String getProblemStatus() {
		return problemStatus;
	}

	public void setProblemStatus(String problemStatus) {
		this.problemStatus = problemStatus;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Set<ProblemAttribute> getProblemAttribute() {
		return problemAttribute;
	}


	public void setProblemAttribute(Set<ProblemAttribute> problemAttribute) {
		this.problemAttribute = problemAttribute;
	}

	public Set<EquipmentDetails> getEquipmentDetails() {
		return equipmentDetails;
	}

	public void setEquipmentDetails(Set<EquipmentDetails> equipmentDetails) {
		this.equipmentDetails = equipmentDetails;
	}

	public Set<ProblemNotes> getProblemNotes() {
		return problemNotes;
	}

	public void setProblemNotes(Set<ProblemNotes> problemNotes) {
		this.problemNotes = problemNotes;
	}

	public String getProbRef() {
		return probRef;
	}

	public void setProbRef(String probRef) {
		this.probRef = probRef;
	}

	@Override
	public String toString() {
		return "Problem [problemId=" + problemId + ", sourceIdentifier=" + sourceIdentifier + ", processKey="
				+ processKey + ", problemStatus=" + problemStatus + ", createdDate=" + createdDate + ", modifyDate="
				+ modifyDate + ", probRef=" + probRef + ", problemAttribute=" + problemAttribute + ", equipmentDetails="
				+ equipmentDetails + ", problemNotes=" + problemNotes + "]";
	}

	
	}
