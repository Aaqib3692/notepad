package com.bt.jarvis.persistence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class ARSolutionMap {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long arSolutionMapId;
	private Long solutionId;
	private Long actionReportId;
	private Long resolutionId;

	
	public Long getActionReportId() {
		return actionReportId;
	}

	public void setActionReportId(Long actionReportId) {
		this.actionReportId = actionReportId;
	}

	

	public Long getSolutionId() {
		return solutionId;
	}

	public void setSolutionId(Long solutionId) {
		this.solutionId = solutionId;
	}

	public Long getArSolutionMapId() {
		return arSolutionMapId;
	}

	public void setArSolutionMapId(Long arSolutionMapId) {
		this.arSolutionMapId = arSolutionMapId;
	}

	public Long getResolutionId() {
		return resolutionId;
	}

	public void setResolutionId(Long resolutionId) {
		this.resolutionId = resolutionId;
	}
	
	
}
