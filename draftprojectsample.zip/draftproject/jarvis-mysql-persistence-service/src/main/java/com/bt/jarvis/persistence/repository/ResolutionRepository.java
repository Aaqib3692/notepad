package com.bt.jarvis.persistence.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bt.jarvis.persistence.entity.Resolution;

@Repository
public interface ResolutionRepository extends PagingAndSortingRepository<Resolution, Long>{
	
public List<Resolution> findByCriteriaContainingAndIsactive(String cr, String rr,Pageable pageable);
public List<Resolution> findByCriteriaContainingAndCriteriaContainingAndIsactive(String criteria,String criteria1, String isActive);

}

