package com.bt.jarvis.persistence.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bt.jarvis.persistence.response.DropDownLabelValue;
import com.bt.jarvis.persistence.response.TempAttributes;
import com.bt.jarvis.persistence.response.TemplateData;
import com.bt.jarvis.persistence.response.TemplateResponse;
import com.bt.jarvis.persistence.service.TemplateService;
import com.bt.jarvis.persistence.util.ServiceUtil;

@Service
public class TemplateServiceImpl implements TemplateService {

	@Override
	public TemplateResponse getTemplateData() {
		TemplateResponse templateResponse = new TemplateResponse();
		List<TemplateData> listTemplateData = new ArrayList<TemplateData>();
		TemplateData templateData = new TemplateData();
		templateData.setTemplateName("21C");
		templateData.setTemplateID("21C");
		
		TempAttributes tempAttributes = new TempAttributes();
		tempAttributes.setAttributeName("Expected Completioe Date Time");
		tempAttributes.setAttributeType("Multi");
		List<DropDownLabelValue> expectedCompletionList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstDate=new DropDownLabelValue();
		firstDate.setLabel(ServiceUtil.getExpectedDate(1));
		firstDate.setValue(ServiceUtil.getExpectedDate(1));
		DropDownLabelValue secondDate=new DropDownLabelValue();
		secondDate.setLabel(ServiceUtil.getExpectedDate(2));
	    secondDate.setValue(ServiceUtil.getExpectedDate(2));
		DropDownLabelValue thirdDate=new DropDownLabelValue();
		thirdDate.setLabel(ServiceUtil.getExpectedDate(3));
		thirdDate.setValue(ServiceUtil.getExpectedDate(3));
		DropDownLabelValue fourthDate=new DropDownLabelValue();
		fourthDate.setLabel(ServiceUtil.getExpectedDate(4));
		fourthDate.setValue(ServiceUtil.getExpectedDate(4));
		expectedCompletionList.add(firstDate);
		expectedCompletionList.add(secondDate);
		expectedCompletionList.add(thirdDate);
		expectedCompletionList.add(fourthDate);
		tempAttributes.setListAttributeValue(expectedCompletionList);
		tempAttributes.setReadable(Boolean.TRUE);

		
		TempAttributes taskType = new TempAttributes();
		taskType.setAttributeName("Task Type");
		taskType.setAttributeType("Multi");
		List<DropDownLabelValue> taskDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstTask=new DropDownLabelValue();
		firstTask.setLabel("RSNN02");
		firstTask.setValue("RSNN02");
		
		DropDownLabelValue secondTask=new DropDownLabelValue();
		secondTask.setLabel("RSNN03");
		secondTask.setValue("RSNN03");
		
		DropDownLabelValue thirdTask=new DropDownLabelValue();
		thirdTask.setLabel("RSNN04");
		thirdTask.setValue("RSNN04");
	
		DropDownLabelValue fourthTask=new DropDownLabelValue();
		fourthTask.setLabel("RSNN05");
		fourthTask.setValue("RSNN05");
		taskDropdownList.add(firstTask);
		taskDropdownList.add(secondTask);
		taskDropdownList.add(thirdTask);
		taskDropdownList.add(fourthTask);
		taskType.setListAttributeValue(taskDropdownList);
		taskType.setReadable(Boolean.TRUE);

		TempAttributes responseCode = new TempAttributes();
		responseCode.setAttributeName("Response Code");
		responseCode.setAttributeType("Multi");
		List<DropDownLabelValue> resDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstRes=new DropDownLabelValue();
		firstRes.setLabel("PA 0");
		firstRes.setValue("PA 0");
		DropDownLabelValue secRes=new DropDownLabelValue();
		secRes.setLabel("PA 1");
		secRes.setValue("PA 1");
		DropDownLabelValue thiRes=new DropDownLabelValue();
		thiRes.setLabel("PA 2");
		thiRes.setValue("PA 2");
		DropDownLabelValue fourthRes=new DropDownLabelValue();
		fourthRes.setLabel("PA 3");
		fourthRes.setValue("PA 3");
		resDropdownList.add(firstRes);
		resDropdownList.add(secRes);
		resDropdownList.add(thiRes);
		resDropdownList.add(fourthRes);
		responseCode.setListAttributeValue(resDropdownList);
		responseCode.setReadable(Boolean.TRUE);

		TempAttributes maintenanceServiceCode = new TempAttributes();
		maintenanceServiceCode.setAttributeName("Maintenance Service Code");
		maintenanceServiceCode.setAttributeType("Multi");
		List<DropDownLabelValue> maintenDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstServiceCode=new DropDownLabelValue();
		firstServiceCode.setLabel("STANDARD CARE");
		firstServiceCode.setValue("STANDARD CARE");
		DropDownLabelValue secServiceCode=new DropDownLabelValue();
		secServiceCode.setLabel("PROMPT CARE");
		secServiceCode.setValue("PROMPT CARE");
		DropDownLabelValue thirdServiceCode=new DropDownLabelValue();
		thirdServiceCode.setLabel("TOTAL CARE");
		thirdServiceCode.setValue("TOTAL CARE");
		maintenDropdownList.add(firstServiceCode);
		maintenDropdownList.add(secServiceCode);
		maintenDropdownList.add(thirdServiceCode);
		maintenanceServiceCode.setListAttributeValue(maintenDropdownList);
		maintenanceServiceCode.setReadable(Boolean.TRUE);

		TempAttributes accessDay = new TempAttributes();
		accessDay.setAttributeName("Access Day");
		accessDay.setAttributeType("Multi");
		List<DropDownLabelValue> accessDayDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstAccessDay=new DropDownLabelValue();
		firstAccessDay.setLabel("SUN");
		firstAccessDay.setValue("SUN");
		DropDownLabelValue secAccessDay=new DropDownLabelValue();
		secAccessDay.setLabel("MON");
		secAccessDay.setValue("MON");
		DropDownLabelValue thirdAccessDay=new DropDownLabelValue();
		thirdAccessDay.setLabel("TUE");
		thirdAccessDay.setValue("TUE");
		DropDownLabelValue fourthAccessDay=new DropDownLabelValue();
		fourthAccessDay.setLabel("WED");
		fourthAccessDay.setValue("WED");
		accessDayDropdownList.add(firstAccessDay);
		accessDayDropdownList.add(secAccessDay);
		accessDayDropdownList.add(thirdAccessDay);
		accessDayDropdownList.add(fourthAccessDay);
		accessDay.setListAttributeValue(accessDayDropdownList);
		accessDay.setReadable(Boolean.TRUE);

		TempAttributes accessStartDateTime = new TempAttributes();
		accessStartDateTime.setAttributeName("Access Start date time");
		accessStartDateTime.setAttributeType("Multi");
		accessStartDateTime.setListAttributeValue(expectedCompletionList);
		accessStartDateTime.setReadable(Boolean.TRUE);

		TempAttributes accessFinishDatetime = new TempAttributes();
		accessFinishDatetime.setAttributeName("Access Finish Date time");
		accessFinishDatetime.setAttributeType("Multi");
		accessFinishDatetime.setListAttributeValue(expectedCompletionList);
		accessFinishDatetime.setReadable(Boolean.TRUE);

		TempAttributes VMThreshold = new TempAttributes();
		VMThreshold.setAttributeName("WM threshold");
		VMThreshold.setAttributeType("input");
		VMThreshold.setAttributeValue("5");
		VMThreshold.setReadable(Boolean.TRUE);

		TempAttributes targetCompletionDate = new TempAttributes();
		targetCompletionDate.setAttributeName("Target Completion date");
		targetCompletionDate.setAttributeType("Multi");
		targetCompletionDate.setListAttributeValue(expectedCompletionList);
		targetCompletionDate.setReadable(Boolean.TRUE);

		TempAttributes systemType = new TempAttributes();
		systemType.setAttributeName("System type");
		systemType.setAttributeType("Multi");
		List<DropDownLabelValue> systemTypeDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstSystemType=new DropDownLabelValue();
		firstSystemType.setLabel("ALM");
		firstSystemType.setValue("ALM");
		DropDownLabelValue secSystemType=new DropDownLabelValue();
		secSystemType.setLabel("BTC");
		secSystemType.setValue("BTC");
		DropDownLabelValue thirdSystemType=new DropDownLabelValue();
		thirdSystemType.setLabel("CSS");
		thirdSystemType.setValue("CSS");
		DropDownLabelValue fourthSystemType=new DropDownLabelValue();
		fourthSystemType.setLabel("TXS");
		fourthSystemType.setValue("TXS");
		systemTypeDropdownList.add(firstSystemType);
		systemTypeDropdownList.add(secSystemType);
		systemTypeDropdownList.add(thirdSystemType);
		systemTypeDropdownList.add(fourthSystemType);
		systemType.setListAttributeValue(systemTypeDropdownList);
		systemType.setReadable(Boolean.TRUE);

		TempAttributes iMPScore = new TempAttributes();
		iMPScore.setAttributeName("IMP Score");
		iMPScore.setAttributeType("input");
		iMPScore.setAttributeValue("15");
		iMPScore.setReadable(Boolean.FALSE);

		TempAttributes mainWorkLocation = new TempAttributes();
		mainWorkLocation.setAttributeName("Main Work Location");
		mainWorkLocation.setAttributeType("Multi");
		List<DropDownLabelValue> mainWorkDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue firstWorkLocation=new DropDownLabelValue();
		firstWorkLocation.setLabel("EX");
		firstWorkLocation.setValue("EX");
		DropDownLabelValue secondWorkLocation=new DropDownLabelValue();
		secondWorkLocation.setLabel("CP");
		secondWorkLocation.setValue("CP");
		DropDownLabelValue thirdWorkLocation=new DropDownLabelValue();
		thirdWorkLocation.setLabel("CV");
		thirdWorkLocation.setValue("CV");
		DropDownLabelValue fourthWorkLocation=new DropDownLabelValue();
		fourthWorkLocation.setLabel("FM");
		fourthWorkLocation.setValue("FM");
		mainWorkDropdownList.add(firstSystemType);
		mainWorkDropdownList.add(secSystemType);
		mainWorkDropdownList.add(thirdSystemType);
		mainWorkDropdownList.add(fourthSystemType);
		mainWorkLocation.setListAttributeValue(mainWorkDropdownList);
		mainWorkLocation.setReadable(Boolean.TRUE);

		TempAttributes accessToSite = new TempAttributes();
		accessToSite.setAttributeName("Access to site");
		accessToSite.setAttributeType("Multi");
		List<DropDownLabelValue> accessSiteDropdownList = new ArrayList<DropDownLabelValue>();
		DropDownLabelValue yesAccessSite=new DropDownLabelValue();
		yesAccessSite.setLabel("Yes");
		yesAccessSite.setValue("Yes");
		DropDownLabelValue noAccessSite=new DropDownLabelValue();
		noAccessSite.setLabel("No");
		noAccessSite.setValue("No");
		accessSiteDropdownList.add(yesAccessSite);
		accessSiteDropdownList.add(noAccessSite);
		accessToSite.setListAttributeValue(accessSiteDropdownList);
		accessToSite.setReadable(Boolean.TRUE);

		

		TempAttributes appointmentStartDateTime = new TempAttributes();
		appointmentStartDateTime.setAttributeName("Appointment Start Date Time");
		appointmentStartDateTime.setAttributeType("Multi");
		appointmentStartDateTime.setListAttributeValue(expectedCompletionList);
		appointmentStartDateTime.setReadable(Boolean.TRUE);
		
		TempAttributes appointmentLatestStartDateTime = new TempAttributes();
		appointmentLatestStartDateTime.setAttributeName("Appointment Latest Start date time");
		appointmentLatestStartDateTime.setAttributeType("Multi");
		appointmentLatestStartDateTime.setListAttributeValue(expectedCompletionList);
		appointmentLatestStartDateTime.setReadable(Boolean.TRUE);

		TempAttributes customerName = new TempAttributes();
		customerName.setAttributeName("Customer Name");
		customerName.setAttributeType("input");
		customerName.setAttributeValue("Test Consumer");
		customerName.setReadable(Boolean.TRUE);
		
		
		TempAttributes customerTitle = new TempAttributes();
		customerTitle.setAttributeName("Customer Title");
		customerTitle.setAttributeType("input");
		customerTitle.setAttributeValue("Mr");
		customerTitle.setReadable(Boolean.TRUE);
		
		TempAttributes generalNotes = new TempAttributes();
		generalNotes.setAttributeName("General Notes");
		generalNotes.setAttributeType("input");
		generalNotes.setAttributeValue("Test Note");
		generalNotes.setReadable(Boolean.TRUE);
		
		
		TempAttributes hazardNotes = new TempAttributes();
		hazardNotes.setAttributeName("Hazard Notes");
		hazardNotes.setAttributeType("input");
		hazardNotes.setAttributeValue("Test");
		hazardNotes.setReadable(Boolean.TRUE);
		List<TempAttributes> listTempAttributes=new ArrayList<TempAttributes>();
		listTempAttributes.add(tempAttributes);
		listTempAttributes.add(taskType);
		listTempAttributes.add(responseCode);
		listTempAttributes.add(maintenanceServiceCode);
		listTempAttributes.add(accessDay);
		listTempAttributes.add(accessStartDateTime);
		listTempAttributes.add(accessFinishDatetime);
		listTempAttributes.add(VMThreshold);
		listTempAttributes.add(targetCompletionDate);
		listTempAttributes.add(systemType);
		listTempAttributes.add(iMPScore);
		listTempAttributes.add(mainWorkLocation);
		listTempAttributes.add(accessToSite);
		listTempAttributes.add(appointmentStartDateTime);
		listTempAttributes.add(appointmentLatestStartDateTime);
		listTempAttributes.add(customerName);
		listTempAttributes.add(customerTitle);
		listTempAttributes.add(generalNotes);
		listTempAttributes.add(hazardNotes);
		templateData.setTempAttributes(listTempAttributes);
		listTemplateData.add(templateData);
		templateResponse.setTemplateData(listTemplateData);
		return templateResponse;
	}

}
