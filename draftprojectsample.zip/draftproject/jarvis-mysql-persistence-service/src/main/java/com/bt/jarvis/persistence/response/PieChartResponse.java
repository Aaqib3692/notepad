package com.bt.jarvis.persistence.response;

import java.util.List;

public class PieChartResponse {
	
	private List<PieChart> pieChart;
	
	private Cards cards;

	public List<PieChart> getPieChart() {
		return pieChart;
	}

	public void setPieChart(List<PieChart> pieChart) {
		this.pieChart = pieChart;
	}

	public Cards getCards() {
		return cards;
	}

	public void setCards(Cards cards) {
		this.cards = cards;
	}
	
	
	
	
	

}
