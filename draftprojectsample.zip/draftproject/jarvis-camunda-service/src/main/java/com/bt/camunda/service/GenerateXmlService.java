package com.bt.camunda.service;

import java.io.File;
import java.io.StringWriter;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Service
public class GenerateXmlService {

	public String xmlTojavaObj(Map<String, String> requestMap) {
		
		String userHomeDir = System.getProperty("user.home");
		userHomeDir=userHomeDir+ "/" +"workManagement.xml";
		String filePath = "src/main/resources/workManagement.xml";
		File xmlFile = new File(userHomeDir);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		StringWriter writer = new StringWriter();
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			if(!requestMap.isEmpty()) {
				if(requestMap.containsKey("1141_code")) {
					updateAttributeValue(doc, "S25:attributeValue", requestMap.get("1141_code"));
				}
				if(requestMap.containsKey("maintainceCode")) {
					updateAttributeValue(doc, "S4:name", requestMap.get("maintainceCode"));
				}
				if(requestMap.containsKey("responseCode")) {
					updateAttributeValue(doc, "S17:responseIndicator", requestMap.get("responseCode"));
				}
				if(requestMap.containsKey("workLocation")) {
					updateAttributeValue(doc, "S6:mainproblemLocation", requestMap.get("workLocation"));
				}
				if(requestMap.containsKey("taskIdentifier")) {
					updateAttributeValue(doc, "header:contextItem", requestMap.get("taskIdentifier"));
					updateAttributeValue(doc, "S8:value", requestMap.get("taskIdentifier"));
				}
				
				if(requestMap.containsKey("tasktype")) {
					
					getListAttribute(doc,requestMap.get("tasktype"));
				}

			}
			// write the updated document to file or console
			doc.getDocumentElement().normalize();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(xmlFile);
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, new StreamResult(writer));

			System.out.println("XML file updated successfully");

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return writer.toString();
	}

	private static void updateAttributeValue(Document doc, String attributeName, String attributeValue) {
		NodeList node = doc.getElementsByTagName(attributeName);	
		Node name = node.item(0).getFirstChild();
		name.setNodeValue(attributeValue);

	}

	private static void getListAttribute(Document doc, String attributeValue) {
		NodeList nodeList = doc.getElementsByTagName("S17:taskCharacteristic");
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				String s8Nme = element.getElementsByTagName("S8:name").item(0).getTextContent();
				String s8Value = element.getElementsByTagName("S8:value").item(0).getTextContent();
				if (s8Nme != null && s8Value != null && "TaskType".equalsIgnoreCase(s8Nme)) {
					element.getElementsByTagName("S8:value").item(0).setTextContent(attributeValue);

				}
			}
		}


	}
}
