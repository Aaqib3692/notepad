package com.bt.camunda.utils;

import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import brave.propagation.ExtraFieldPropagation;

@Service("logUtil")
public class LoggerUtil{

	private static final Logger delegateLogger = LoggerFactory.getLogger(LoggerUtil.class);
	private static final String TASK_ID = "X-taskId";
	
	public boolean clearFromContext(String key) {
		MDC.remove(key);
		return true;
	}

	public boolean addToContext(String key, String value) {
		MDC.put(key, value);
		ExtraFieldPropagation.set(key, value);
		return true;
	}
	
	public void taskProcessing(String taskId, Object payload) {
		try {
			DelegateExecution execution = null;
			if((taskId==null || taskId.isEmpty()) && payload instanceof DelegateExecution) {
				execution = (DelegateExecution) payload;
				taskId = execution.getProcessInstanceId() + "_" + execution.getCurrentActivityName();
				payload = execution.getVariables();
				execution.setVariableLocal("taskId", taskId);
			}
			addToContext(TASK_ID, taskId);
			logInfo("Processing task <{}> - <{}>", taskId, execution.getCurrentActivityName());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			delegateLogger.error("Logger could not be processed. Exception <{}>", e.getMessage());
		}
	}
	
	public void taskCompleted(String taskId, Integer statusCode, String statusMessage, Object payload) throws Exception {
		try {
			if (statusCode >= 200 && statusCode < 300)
				logInfo("Task <{}> processing completed with CLOSED - statusCode: <{}>, statusMessage: <{}>, output: <{}>",
						taskId, HttpStatus.valueOf(statusCode).value(),
						HttpStatus.valueOf(statusCode).getReasonPhrase(),
						payload instanceof String ? payload : new ObjectMapper().writeValueAsString(payload));
			else {
				taskFailed(taskId, statusCode, statusMessage, payload, statusMessage);
			}
			
			clearFromContext(TASK_ID);
		} catch (JsonProcessingException e) {
			delegateLogger.error("Logger could not be processed. Exception <{}>", e.getMessage());
		}
	}

	public void taskFailed(String taskId, Integer statusCode, String statusMessage, Object payload, String exception) {
		try {
			logError("Task <{}> processing completed with FAILED - statusCode: <{}>, statusMessage: <{}>, output: <{}>",
					taskId, HttpStatus.valueOf(statusCode).value(), "FAILED", 
					payload instanceof String ? payload : new ObjectMapper().writeValueAsString(payload));
			clearFromContext(TASK_ID);
		} catch (JsonProcessingException e) {
			delegateLogger.error("Logger could not be processed. Exception <{}>", e.getMessage());
		} 
	}

	/**
	 * Logs a 'INFO' message 
	 * @param params
	 */
	public void logInfo(String message, Object... parameters) {
		delegateLogger.info(message, parameters);
	}

	/**
	 * Logs a 'DEBUG' message 
	 * @param params
	 */
	public void logDebug(String message, Object... parameters) {
		delegateLogger.debug(message, parameters);
	}

	/**
	 * Logs an 'ERROR' message 
	 * @param params
	 */
	public void logError(String message, Object... parameters) {
		delegateLogger.error(message, parameters);
	}

}
