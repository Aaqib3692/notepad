package com.bt.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("connectorTaskDelegate")
public class ConnectorTaskDelegate implements ExecutionListener{

	@Value("${service.backendBaseUrl}")
	private String backendBaseUrl;
	
	@Value("${service.camundaBaseUrl}")
	private String camundaBaseUrl;
	
	
	@Override
	public void notify(DelegateExecution execution) throws Exception {
		
		if(execution.getEventName().equalsIgnoreCase("end")) {
			execution.setVariable("backendBaseUrl", backendBaseUrl);
			execution.setVariable("camundaBaseUrl", camundaBaseUrl);
		}
		
	}
	
}
