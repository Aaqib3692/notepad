package com.bt.camunda.controller.AutofixController;

import java.io.IOException;
import java.util.Map;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bt.camunda.service.GenerateXmlService;
import com.bt.camunda.utils.LoggerUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin("*")
@RestController
public class AutofixController {
	private static final Logger log = LoggerFactory.getLogger(AutofixController.class);
	private LoggerUtil util = new LoggerUtil();
	
	@Autowired 
    private RuntimeService runtimeService;
	
	@Autowired
	private GenerateXmlService generateXmlService;
	
	@Autowired
	private LoggerUtil logUtil;
	
	@PostMapping("/process-defination/key/{processDefinationKey}/start")
	public ResponseEntity<Object>  startProcessInstance(@RequestBody String inputData,@PathVariable String processDefinationKey) {
		log.info("Request received - payload <{}>", inputData);
		
		VariableMap variables=Variables.createVariables().putValue("inputJson", inputData);

		//start process instance
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinationKey,variables);

		//get final response
		String finalResponse = (String) runtimeService.getVariable(processInstance.getId(), "finalResponse");
		
		runtimeService.signalEventReceived("exitSignal", runtimeService.getVariables(processInstance.getId()));
		
		log.info("Request completed - process id - <{}>", processInstance.getId());
		return new ResponseEntity<>(finalResponse, HttpStatus.OK);

	}
	
	@PostMapping("/generateXml")
	public ResponseEntity<Object> generateXml(@RequestBody JsonNode inputData){
		log.info("Request received - payload <{}>", inputData);
		ObjectMapper mapper=new ObjectMapper();
		String response= null;
		Map<String,String> requestMap=null;
		try {
			requestMap=mapper.readValue(inputData.toString(), Map.class);
			response = generateXmlService.xmlTojavaObj(requestMap);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		log.info("Request completed - response - <{}>", response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
}