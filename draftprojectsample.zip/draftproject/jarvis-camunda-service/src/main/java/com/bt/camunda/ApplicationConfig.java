package com.bt.camunda;

import java.util.List;

import org.camunda.bpm.engine.impl.cfg.CompositeProcessEnginePlugin;
import org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.camunda.bpm.engine.impl.cfg.ProcessEnginePlugin;
import org.camunda.bpm.engine.impl.cfg.SpringBeanFactoryProxyMap;
import org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration;
import org.camunda.bpm.spring.boot.starter.util.CamundaSpringBootUtil;

@Configuration
public class ApplicationConfig {

	 @Bean
	  public ProcessEngineConfigurationImpl processEngineConfigurationImpl(
	       List<ProcessEnginePlugin> processEnginePlugins,
	       ApplicationContext applicationContext) {
	    final SpringProcessEngineConfiguration configuration = CamundaSpringBootUtil.springProcessEngineConfiguration();
	    configuration.getProcessEnginePlugins().add(new CompositeProcessEnginePlugin(processEnginePlugins));
	    configuration.setBeans(new SpringBeanFactoryProxyMap(applicationContext));
	    configuration.setApplicationContext(applicationContext);
	    return configuration;
	  }
}
