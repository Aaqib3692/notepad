package com.bt.kafka.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan("com.bt.kafka")
public class StompProducerApplication {

	public static void main(String[] args) {

			SpringApplication.run(StompProducerApplication.class, args);

	}

}
